# Extras

This directory contains assets that are not complete **Scene2D** skins, but might be still useful for your UI.
