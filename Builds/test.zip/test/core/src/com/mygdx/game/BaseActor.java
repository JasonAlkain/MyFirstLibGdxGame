package com.mygdx.game;

import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Vector2;

public class BaseActor<string> {
    ShapeRenderer sr;
    Vector2 Pos;
    string Tag;

}
